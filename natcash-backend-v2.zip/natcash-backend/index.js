// ═══════════════════════════════════════════════════════════════
//  JUVENS TOP UP — NatCash Backend v2
//  Déployer sur Render.com (Free tier)
//  Node.js 18+
// ═══════════════════════════════════════════════════════════════

const express = require("express");
const cors    = require("cors");
const app     = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── Base de données en mémoire (persiste tant que le serveur tourne) ──
// Structure : { transcode: { amount, sender, date, used, raw } }
const SMS_DB = {};

// ═══════════════════════════════════════════════════════════════
//  PARSER SMS NATCASH
//  Gère tous les formats NatCash Haïti :
//
//  Format 1 (réception) :
//  "Ou resevwa 480 HTG nan Unknown 55517941 nan 11:48 10/06/2026,
//   kontni: Lajan topup. Balans ou: 481.6 HTG. Transcode: 26061054755594. Mesi"
//
//  Format 2 (transfert sortant) :
//  "You transferred 100 HTG to JERO... Transcode: XXXXXX"
//
//  Format 3 (ancien format court) :
//  "TransCode: 123456"
// ═══════════════════════════════════════════════════════════════
function parseSMS(text) {
  if (!text) return null;

  const result = {
    transcode : null,
    amount    : null,
    sender    : null,
    type      : null,   // "received" | "sent"
    raw       : text,
  };

  // ── Extraire Transcode (toutes longueurs : 6 à 20 chiffres) ──
  const tcMatch = text.match(/[Tt]ranscode[:\s]+([0-9]{5,20})/);
  if (tcMatch) result.transcode = tcMatch[1].trim();

  // ── Montant ──
  const amtMatch = text.match(/([0-9]+(?:\.[0-9]+)?)\s*HTG/);
  if (amtMatch) result.amount = parseFloat(amtMatch[1]);

  // ── Type + expéditeur ──
  if (/[Oo]u resevwa|received/i.test(text)) {
    result.type = "received";
    // Extraire numéro expéditeur : "nan Unknown 55517941"
    const senderMatch = text.match(/nan\s+(?:Unknown\s+)?([0-9]{7,11})/i);
    if (senderMatch) result.sender = senderMatch[1];
  } else if (/transferred|voye|envoy/i.test(text)) {
    result.type = "sent";
  }

  return result.transcode ? result : null;
}

// ═══════════════════════════════════════════════════════════════
//  POST /sms-webhook
//  Reçoit les SMS depuis "Transitaire SMS" / "SMS Forwarder"
//  Body attendu : { from, message, date } ou { body, address }
// ═══════════════════════════════════════════════════════════════
app.post("/sms-webhook", (req, res) => {
  // Compatibilité multi-app (Transitaire SMS, SMS Forwarder, SMSToURL)
  const raw  = req.body.message || req.body.body || req.body.sms || req.body.text || "";
  const from = req.body.from    || req.body.address || req.body.sender || "Unknown";
  const date = req.body.date    || new Date().toISOString();

  console.log(`[SMS reçu] De: ${from} | Message: ${raw.substring(0, 80)}`);

  const parsed = parseSMS(raw);

  if (!parsed) {
    console.log("[SMS ignoré] Pas de Transcode trouvé.");
    return res.json({ success: false, reason: "no_transcode" });
  }

  // Sauvegarder dans la DB (transcode comme clé)
  SMS_DB[parsed.transcode] = {
    amount  : parsed.amount,
    sender  : parsed.sender || from,
    type    : parsed.type,
    date    : date,
    used    : false,
    raw     : raw,
  };

  console.log(`[SMS sauvegardé] Transcode: ${parsed.transcode} | Montant: ${parsed.amount} HTG`);
  res.json({ success: true, transcode: parsed.transcode, amount: parsed.amount });
});

// ═══════════════════════════════════════════════════════════════
//  GET /verify-natcash?code=XXXXXXXX
//  Vérifie si un Transcode existe et n'est pas déjà utilisé
// ═══════════════════════════════════════════════════════════════
app.get("/verify-natcash", (req, res) => {
  const code = (req.query.code || "").trim();

  if (!code) {
    return res.status(400).json({ success: false, reason: "missing_code" });
  }

  const entry = SMS_DB[code];

  if (!entry) {
    console.log(`[Vérification] Transcode ${code} → NOT FOUND`);
    return res.json({ success: false, reason: "not_found" });
  }

  if (entry.used) {
    console.log(`[Vérification] Transcode ${code} → DÉJÀ UTILISÉ`);
    return res.json({ success: false, reason: "already_used" });
  }

  console.log(`[Vérification] Transcode ${code} → VALIDE (${entry.amount} HTG)`);
  res.json({
    success  : true,
    transcode: code,
    amount   : entry.amount,
    sender   : entry.sender,
    date     : entry.date,
    type     : entry.type,
  });
});

// ═══════════════════════════════════════════════════════════════
//  POST /mark-used
//  Marque un Transcode comme utilisé après crédit du wallet
//  Body : { code }
// ═══════════════════════════════════════════════════════════════
app.post("/mark-used", (req, res) => {
  const code = (req.body.code || "").trim();

  if (!code || !SMS_DB[code]) {
    return res.status(404).json({ success: false, reason: "not_found" });
  }

  SMS_DB[code].used = true;
  console.log(`[Mark Used] Transcode ${code} marqué comme utilisé.`);
  res.json({ success: true });
});

// ═══════════════════════════════════════════════════════════════
//  GET /status  — Health check (Render ping)
// ═══════════════════════════════════════════════════════════════
app.get("/status", (req, res) => {
  res.json({
    status   : "online",
    sms_count: Object.keys(SMS_DB).length,
    uptime   : Math.floor(process.uptime()) + "s",
  });
});

// ── Démarrage ──
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ NatCash Backend v2 lancé sur port ${PORT}`);
});
